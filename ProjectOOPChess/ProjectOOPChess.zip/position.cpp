#include "position.h"
#include "stdafx.h"

void position::setX(int _x)
{
	this->x = _x;
}

void position::setY(int _y)
{
	this->y = _y;
}

int position::getX() const
{
	return x;
}

int position::getY() const
{
	return y;
}